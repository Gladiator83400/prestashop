<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{uecookie}prestashop>uecookie_77dd54e4f719c6fb0c2e23452eb830da'] = 'Europese Unie cookie-wetgeving';
$_MODULE['<{uecookie}prestashop>uecookie_fba6a93b46d375a50cb1c58b84899053'] = 'Deze module toont een mooie informatie over cookies in uw winkel';
$_MODULE['<{uecookie}prestashop>uecookie_1061fda795260b08e769c493105557f7'] = 'Deze winkel maakt gebruik van cookies en andere technologieën, zodat we kunnen verbeteren uw ervaring op onze sites.';
$_MODULE['<{uecookie}prestashop>uecookie_d12652129be13b431f0e491afac0d4fe'] = 'Europese Unie cookie-wetgeving';
$_MODULE['<{uecookie}prestashop>uecookie_4d1d06e0e2f0a31f2806796bf0513c1a'] = 'tekst hier';
$_MODULE['<{uecookie}prestashop>uecookie_43781db5c40ecc39fd718685594f0956'] = 'instellingen opslaan';
