<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{uecookie}prestashop>top_716f6b30598ba30945d84485e61c1027'] = 'aceptar';
$_MODULE['<{uecookie}prestashop>uecookie_f0e771ccfbef7b8ac8511bb63994feef'] = 'European Union Cookies Law';
$_MODULE['<{uecookie}prestashop>uecookie_fba6a93b46d375a50cb1c58b84899053'] = 'Este módulo muestra una buena información sobre las Cookies en su tienda';
$_MODULE['<{uecookie}prestashop>uecookie_1061fda795260b08e769c493105557f7'] = 'Esta tienda utiliza cookies y otras tecnologías para que podamos mejorar su experiencia en nuestros sitios.';
$_MODULE['<{uecookie}prestashop>uecookie_d12652129be13b431f0e491afac0d4fe'] = 'Unión Europea \"Cookie\" ley';
$_MODULE['<{uecookie}prestashop>uecookie_4d1d06e0e2f0a31f2806796bf0513c1a'] = 'texto aquí';
$_MODULE['<{uecookie}prestashop>uecookie_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'posición';
$_MODULE['<{uecookie}prestashop>uecookie_b28354b543375bfa94dabaeda722927f'] = 'superior';
$_MODULE['<{uecookie}prestashop>uecookie_71f262d796bed1ab30e8a2d5a8ddee6f'] = 'parte inferior';
$_MODULE['<{uecookie}prestashop>uecookie_368d9ac76af05f714092bc808a426bfc'] = 'Color de fondo';
$_MODULE['<{uecookie}prestashop>uecookie_ee5488740d9345ae7768b839dd81c608'] = 'Color de la sombra.';
$_MODULE['<{uecookie}prestashop>uecookie_bad6a5dd8c28e6b14f8e986615e3dc98'] = 'opacidad';
$_MODULE['<{uecookie}prestashop>uecookie_82968569cca21c585a15d46ee3b58253'] = 'por ejemplo: 0.5 (punto como separador decimal!)';
$_MODULE['<{uecookie}prestashop>uecookie_43781db5c40ecc39fd718685594f0956'] = 'Salvar';
