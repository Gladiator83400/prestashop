<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['top_716f6b30598ba30945d84485e61c1027'] = 'Ok';
$_MODULE['uecookie_fba6a93b46d375a50cb1c58b84899053'] = 'A modul segítségével engedélyt kérhetsz a sütik alkalmazásához.';
$_MODULE['uecookie_1061fda795260b08e769c493105557f7'] = 'A weboldal cookie-kat alkalmaz, hogy a legjobb felhasználói élményt nyújthassuk Önneknek.';
$_MODULE['uecookie_d12652129be13b431f0e491afac0d4fe'] = 'EU törvény – Sütik (cookie) engedélyeztetése a felhasználókkal.';
$_MODULE['uecookie_4d1d06e0e2f0a31f2806796bf0513c1a'] = 'Szöveg';
$_MODULE['uecookie_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Elhelyezkedés:';
$_MODULE['uecookie_b28354b543375bfa94dabaeda722927f'] = 'Felül';
$_MODULE['uecookie_71f262d796bed1ab30e8a2d5a8ddee6f'] = 'Alul';
$_MODULE['uecookie_368d9ac76af05f714092bc808a426bfc'] = 'A szöveg színe:';
$_MODULE['uecookie_ee5488740d9345ae7768b839dd81c608'] = 'Az árnyék színe:';
$_MODULE['uecookie_bad6a5dd8c28e6b14f8e986615e3dc98'] = 'Átlátszóság:';
$_MODULE['uecookie_82968569cca21c585a15d46ee3b58253'] = 'például: 0.5';
$_MODULE['uecookie_43781db5c40ecc39fd718685594f0956'] = 'Mentés';
