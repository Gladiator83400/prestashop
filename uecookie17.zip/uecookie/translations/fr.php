<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{uecookie}prestashop>top_716f6b30598ba30945d84485e61c1027'] = 'J\'accepte';
$_MODULE['<{uecookie}prestashop>uecookie_f0e771ccfbef7b8ac8511bb63994feef'] = 'Législation Européenne concernant l\'utilisation des cookies';
$_MODULE['<{uecookie}prestashop>uecookie_fba6a93b46d375a50cb1c58b84899053'] = 'Ce module affiche un bandeau d\'information sur votre boutique PrestaShop, conformément à la législation Européenne sur l\'utilisation des cookies';
$_MODULE['<{uecookie}prestashop>uecookie_1061fda795260b08e769c493105557f7'] = 'En poursuivant votre navigation sur ce site, vous devez accepter l’utilisation et l\'écriture de Cookies sur votre appareil connecté. Ces Cookies (petits fichiers texte) permettent de suivre votre navigation, actualiser votre panier, vous reconnaitre lors de votre prochaine visite et sécuriser votre connexion. Pour en savoir plus et paramétrer les traceurs: http://www.cnil.fr/vos-obligations/sites-web-cookies-et-autres-traceurs/que-dit-la-loi/';
$_MODULE['<{uecookie}prestashop>uecookie_d12652129be13b431f0e491afac0d4fe'] = 'Législation Européenne concernant l\'utilisation des cookies';
$_MODULE['<{uecookie}prestashop>uecookie_4d1d06e0e2f0a31f2806796bf0513c1a'] = 'Texte d\'avertissement aux utilisateurs:';
$_MODULE['<{uecookie}prestashop>uecookie_b28354b543375bfa94dabaeda722927f'] = 'Haut';
$_MODULE['<{uecookie}prestashop>uecookie_71f262d796bed1ab30e8a2d5a8ddee6f'] = 'Bas';
$_MODULE['<{uecookie}prestashop>uecookie_368d9ac76af05f714092bc808a426bfc'] = 'Couleur d\'arrière-plan';
$_MODULE['<{uecookie}prestashop>uecookie_ee5488740d9345ae7768b839dd81c608'] = 'Couleur d\'ombre';
$_MODULE['<{uecookie}prestashop>uecookie_bad6a5dd8c28e6b14f8e986615e3dc98'] = 'Opacité';
$_MODULE['<{uecookie}prestashop>uecookie_82968569cca21c585a15d46ee3b58253'] = '0.5 par exemple';
$_MODULE['<{uecookie}prestashop>uecookie_43781db5c40ecc39fd718685594f0956'] = 'Enregistrer les paramètres';
