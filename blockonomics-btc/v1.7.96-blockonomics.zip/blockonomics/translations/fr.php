<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockonomics}prestashop>blockonomics_2cd248faec609d132624980e19c7ca97']
    = 'Bitcoin - Blockonomics';
$_MODULE['<{blockonomics}prestashop>blockonomics_c0de713a1b5c4354ebbd1e2227ce971b']
    = 'Module de paiement par Bitcoin';
$_MODULE['<{blockonomics}prestashop>blockonomics_876f23178c29dc2552c0b48bf23cd9bd']
    = 'Êtes-vous sûr de vouloir désinstaller le module ?';
$_MODULE['<{blockonomics}prestashop>blockonomics_2f14ecdf24da27a9fb0ded962aa17e8c']
    = 'Veuillez entrer une clé API';
$_MODULE['<{blockonomics}prestashop>blockonomics_575792812af3733426415dc226913037']
    = 'Payer avec Bitcoin';
$_MODULE['<{blockonomics}prestashop>blockonomics_db84ee92e4da32563f91afe070e37a7e']
    = 'Votre serveur bloque les appels HTTPS sortants';
$_MODULE['<{blockonomics}prestashop>blockonomics_71d736bf8acac6f396861493102750d1']
    = 'La clé API est incorrecte';
$_MODULE['<{blockonomics}prestashop>blockonomics_baa8441e3dbb790354e36e17e77d960a']
    = 'Veuillez ajouter un nouveau magasin sur le site Web de blockonomics';
$_MODULE['<{blockonomics}prestashop>blockonomics_98c2637920a4f98d40f7f6b0fc2fd378']
    = 'Pour plus d\'informations, veuillez consulter ce ';
$_MODULE['<{blockonomics}prestashop>blockonomics_c3d515262545a5bde7c683f68afe06f9']
    = 'guide de dépannage';
$_MODULE['<{blockonomics}prestashop>blockonomics_f75cbf4937d2f1f31e6a4c727ebfee7b']
    = 'La configuration est terminée !';
$_MODULE['<{blockonomics}prestashop>blockonomics_e576911d3083c76abba01c8a03842856']
    = 'Paramètres enregistrés. Cliquez sur Tester la configuration pour vérifier l\'installation.';
$_MODULE['<{blockonomics}prestashop>blockonomics_f4f70727dc34561dfde1a3c529b6205c']
    = 'Paramètres';
$_MODULE['<{blockonomics}prestashop>blockonomics_d876ff8da67c3731ae25d8335a4168b4']
    = 'Clé API';
$_MODULE['<{blockonomics}prestashop>blockonomics_4090c73f435e12febebe689cdf79031e']
    = 'URL DE RAPPEL HTTP';
$_MODULE['<{blockonomics}prestashop>blockonomics_ff64c6d108f9d4760aaf521fbbabbe8f']
    = 'Durée';
$_MODULE['<{blockonomics}prestashop>blockonomics_1d916369325e045bba284bcbce35ccaf']
    = 'Compte à rebours sur la page de paiement';
$_MODULE['<{blockonomics}prestashop>blockonomics_70abb32fcb0c9e8194526d1eef15eb05']
    = '10 minutes';
$_MODULE['<{blockonomics}prestashop>blockonomics_2a7bb67d9681d8b5c8241cd49c734772']
    = '15 minutes';
$_MODULE['<{blockonomics}prestashop>blockonomics_f31f3ebbdee89a50923676a58da95904']
    = '20 minutes';
$_MODULE['<{blockonomics}prestashop>blockonomics_92f08914683ec10736d27ad9a15fa624']
    = '25 minutes';
$_MODULE['<{blockonomics}prestashop>blockonomics_0d714869027c4e08ea9b2943d9bd704e']
    = '30 minutes';
$_MODULE['<{blockonomics}prestashop>blockonomics_c9cc8cce247e49bae79f15173ce97354']
    = 'Enregistrer';
$_MODULE['<{blockonomics}prestashop>blockonomics_a17379a9752f2e6eef6c319c771f5f44']
    = 'Pour configurer, cliquez ';
$_MODULE['<{blockonomics}prestashop>blockonomics_64f676ae6e961fa1e596eeeeef5c7df9']
    = 'sur Démarrer gratuitement';
$_MODULE['<{blockonomics}prestashop>blockonomics_ed2b5c0139cec8ad2873829dc1117d50']
    = 'le';
$_MODULE['<{blockonomics}prestashop>blockonomics_dfcfc43722eef1eab1e4a12e50a068b1']
    = 'Monnaies';
$_MODULE['<{blockonomics}prestashop>blockonomics_bfacb577033fa77ff21438e5ff80ca3b']
    = 'Bitcoin (BTC)';
$_MODULE['<{blockonomics}prestashop>blockonomics_9cb7ca5565d6c28ff385f66a173c86a7']
    = 'Bitcoin Cash (BCH)';
$_MODULE['<{blockonomics}prestashop>blockonomics_b279be2ec798cea1e5019824662e53e9']
    = 'Tester la configuration';
$_MODULE['<{blockonomics}prestashop>payment_d1228f5476d15142b1358ae4b5fa2454']
    = 'N° de commande';
$_MODULE['<{blockonomics}prestashop>payment_8fd2d4cb88dd67be9d343d3398ca763d']
    = 'Paiement expiré';
$_MODULE['<{blockonomics}prestashop>payment_79d7ff78f59371847aa73f232be2d196']
    = 'Cliquez ici pour réessayer';
$_MODULE['<{blockonomics}prestashop>payment_9e553ea6221b688a01e329cf76dde4bf']
    = 'Le montant de la commande payé en BTC est inférieur au montant attendu. Contacter le marchand';
$_MODULE['<{blockonomics}prestashop>payment_a217a4286be5ab0bd03a98d33a78c420']
    = 'Ouvrir dans le portefeuille';
$_MODULE['<{blockonomics}prestashop>payment_4972448661ca72aa783da607f9b3ecc7']
    = 'Pour effectuer le paiement, envoyer exactement';
$_MODULE['<{blockonomics}prestashop>payment_efc1a46f7b47e4d3cf60f13b6c89069b']
    = 'Copié dans le presse-papier';
$_MODULE['<{blockonomics}prestashop>payment_b187de06406775bc913d0c12c6a5dbe6']
    = 'À cette';
$_MODULE['<{blockonomics}prestashop>payment_ea08ae01e95bb85ba4d51f7fa224a956']
    = 'adresse';
$_MODULE['<{blockonomics}prestashop>payment_df9e1aa4940f7a34263d65ef41b87cf1']
    = 'min';
$_MODULE['<{blockonomics}prestashop>payment_7f0801830c4f3ed63e81fc0053177394']
    = 'Comment payer ? | Consulter les avis sur cette boutique';
$_MODULE['<{blockonomics}prestashop>payment_69616e342259a7da05c26802caf4f0ea']
    = 'Proposé par Blockonomics';
$_MODULE['<{blockonomics}prestashop>no_crypto_7a686f1321744105bd4183854107d431']
    = 'Aucune crypto-monnaie n\'est activée pour les paiements';
$_MODULE['<{blockonomics}prestashop>no_crypto_6387ce01d8a5c7eff4bfc2e74afc1767']
    = 'Note à l\'administrateur : Peut être activée via '.
        'Administrateur PrestaShop > Modules > Gestionnaire de modules > Bitcoin - Blockonomics > Monnaies';
$_MODULE['<{blockonomics}prestashop>select_03a7faed722f23ed1f61d3a49425200b']
    = 'Pay avec';
$_MODULE['<{blockonomics}prestashop>validation_02cb6e7914265feb537fe7078c7a5649']
    = 'Extension PHP absente.';
$_MODULE['<{blockonomics}prestashop>validation_5dbacc8b4262eb20aa2ec42ab2a1ac0b']
    = 'Veuillez installer l\'extension php-intl manquante';
$_MODULE['<{blockonomics}prestashop>payment_eb60ab14749e5732652e66fbaf2bd75e']
    = 'Impossible de générer une adresse bitcoin.';
$_MODULE['<{blockonomics}prestashop>payment_b5511b23e304849b337641e03b9223de']
    = 'Veuillez utiliser le bouton Tester la configuration pour diagnostiquer l\'erreur';
