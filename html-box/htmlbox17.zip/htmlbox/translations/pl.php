<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{htmlbox}prestashop>htmlbox_66e0c17dd87ad977b7d3e3e2cbbc44a7'] = 'HTML box';
$_MODULE['<{htmlbox}prestashop>htmlbox_2a5b55f8f0ea547b659506ee561a1f1d'] = 'Z tym modułem umieścisz dowolny kod HTML/Js/CSS w dowolnym miejscu swojego sklepu';
$_MODULE['<{htmlbox}prestashop>htmlbox_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Potwierdzenie';
$_MODULE['<{htmlbox}prestashop>htmlbox_c888438d14855d7d96a2724ee9c306bd'] = 'Ustawienia zapisane';
$_MODULE['<{htmlbox}prestashop>htmlbox_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Zapisz ustawienia';
